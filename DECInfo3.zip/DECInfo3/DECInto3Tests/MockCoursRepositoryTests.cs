using DECInfo3.Controllers;
using DECInfo3.Data;
using System;
using System.Threading.Tasks;
using Xunit;

namespace DECInto3Tests
{
	public class MockCoursRepositoryTests
	{
		[Fact]
		public async Task Test_Index_Returns_A_ViewResult()
		{
			//Arrange
			var mockRepo = new MockCoursRepository();
			var controller = new CoursController(mockRepo);

			//Act
			var resualt = await controller.Index();

		}
	}
}
