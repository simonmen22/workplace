﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DECInfo3.Data;
using DECInfo3.Models;

namespace DECInfo3.Data
{
	public class MockCoursRepository : IRepository<Cours>
	{
		private readonly List<Cours> _cours;

		public MockCoursRepository()
		{
			_cours = new List<Cours>()
			{
				new Cours(){ID=1, Titre = "Analyse1", Description = "Cours le fun", Professeur = "Daniel"},
				new Cours(){ID=2, Titre = "Algo2", Description = "Trop facile pour vous", Professeur = "Daniel"},
			};

		}

		public Task Add(Cours entity)
		{
			throw new NotImplementedException();
		}

		public Task Delete(Cours entity)
		{
			throw new NotImplementedException();
		}

		public Task Update(Cours entity)
		{
			throw new NotImplementedException();
		}

		Task<IQueryable<Cours>> IRepository<Cours>.GetAll()
		{
			throw new NotImplementedException();
		}

		Task<Cours> IRepository<Cours>.GetByID(int? id)
		{
			throw new NotImplementedException();
		}
	}
}
