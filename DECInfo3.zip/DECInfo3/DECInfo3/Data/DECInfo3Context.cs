﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using DECInfo3.Models;

namespace DECInfo3.Models
{
    public class DECInfo3Context : DbContext
    {
        public DECInfo3Context (DbContextOptions<DECInfo3Context> options)
            : base(options)
        {
        }

        public DbSet<DECInfo3.Models.Cours> Cours { get; set; }

        public DbSet<DECInfo3.Models.Prof> Prof { get; set; }
    }
}
