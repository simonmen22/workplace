﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using DECInfo3.Models;
using DECInfo3.Data;
using DECInfo3.Controllers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Mvc;

namespace DECInfo3.Models
{
    public class DECInfo3Repository<T> : IRepository<T> where T : Entity
    {
		private readonly IServiceScopeFactory scopeFactory;

		public DECInfo3Repository(IServiceScopeFactory scopeFactory)
		{
			this.scopeFactory = scopeFactory;
		}

		public async Task Add(T entity)
		{
			using (var scope = scopeFactory.CreateScope())
			{
				var dbContext = scope.ServiceProvider.GetRequiredService<DECInfo3Context>();
				var items = dbContext.Set<T>();
				await items.AddAsync(entity);
				return;
			}
		}

		/*public async Task Delete(T entity)
		{
			using (var scope = scopeFactory.CreateScope())
			{
				var dbContext = scope.ServiceProvider.GetRequiredService<DECInfo3Context>();

				var item = await dbContext.Set<T>().FindAsync(entity.ID);
				if (item == null)
				{
					return;
				}
				dbContext.Remove(entity);
				return;
			}
		}*/

		public async Task<IQueryable<T>> GetAll()
		{

			
			using (var scope = scopeFactory.CreateScope())
			{
				var dbContext = scope.ServiceProvider.GetRequiredService<DECInfo3Context>();
				var items = dbContext.Set<T>();
				return (IQueryable<T>)await items.ToListAsync();
			}
		}

		/*public async Task<T> GetByID(int? id)
		{
			using (var scope = scopeFactory.CreateScope())
			{
				var dbContext = scope.ServiceProvider.GetRequiredService<DECInfo3Context>();
				if (id == null)
				{
					return null;
				}
				var item = await dbContext.Set<T>().FindAsync(id);
				if (item == null)
				{
					return null;
				}
				return item;
			}
		}

		public async Task Update(T entity)
		{
			using (var scope = scopeFactory.CreateScope())
			{
				//
			}
		}*/
	}
}
