﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DECInfo3.Data;
using DECInfo3.Models;

namespace DECInfo3.Data
{
	public class MockProfRepository : IRepository<Prof>
	{
		private readonly List<Prof> _profs;

		public MockProfRepository()
		{
			_profs = new List<Prof>()
			{
				new Prof(){ID=1, Name = "Daniel", Permanent = true},
				new Prof(){ID=2, Name = "Simon", Permanent = false},
			};

		}

		public Task Add(Prof entity)
		{
			throw new NotImplementedException();
		}

		public Task Delete(Prof entity)
		{
			throw new NotImplementedException();
		}

		public Task<IQueryable<Prof>> GetAll()
		{
			throw new NotImplementedException();
		}

		public Task<Prof> GetByID(int? id)
		{
			throw new NotImplementedException();
		}

		public Task Update(Prof entity)
		{
			throw new NotImplementedException();
		}
	}
}
