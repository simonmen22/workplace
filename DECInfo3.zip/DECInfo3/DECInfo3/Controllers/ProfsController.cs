﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DECInfo3.Models;
using DECInfo3.Data;

namespace DECInfo3.Controllers
{
    public class ProfsController : Controller
    {
		private IRepository<Prof> _profRepository;

		public ProfsController(IRepository<Prof> profRepository)
        {
			_profRepository = profRepository;
        }
	}
}
