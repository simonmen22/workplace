﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace DECInfo3.Controllers
{
    public class TestController : Controller
    {
    /*    public IActionResult Index()
        {
			ViewData["nom"] = "Simon";
			ViewData["id"] = 9;

			return View();
        }*/

		public string Index()
		{
			return "Index is working";
		}

		public string TestMethod()
		{
			return "TestMethod is working";
		}

		public string MethodParam(string nom, int id = 1)
		{
			return HtmlEncoder.Default.Encode($"MethodParam {nom} is {id}");
		}
		
	}
}