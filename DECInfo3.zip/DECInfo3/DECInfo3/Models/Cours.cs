﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using DECInfo3.Data;

namespace DECInfo3.Models
{
	public class Cours : Entity
	{
		public string Titre { get; set; }
		public string Professeur { get; set; }
		public string Description { get; set; }
	}
}
