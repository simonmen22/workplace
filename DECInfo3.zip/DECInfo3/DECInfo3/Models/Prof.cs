﻿using DECInfo3.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DECInfo3.Models
{
	public class Prof : Entity
	{
		public string Name { get; set; }
		public Boolean Permanent { get; set; }
	}
}
