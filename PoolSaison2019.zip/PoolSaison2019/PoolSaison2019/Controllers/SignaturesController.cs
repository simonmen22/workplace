﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace PoolSaison2019.Controllers
{
    public class SignaturesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

		public IActionResult SignatureRecente(string id = "-1", string lastName = " ", string city = " ")
		{
			ViewData["id"] = id;
			ViewData["lastName"] = lastName;
			ViewData["city"] = city;

			return View();
		}
	}
}