﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PoolSaison2019.Models;

namespace PoolSaison2019.Controllers
{
    public class ParticipantsController : Controller
    {
        private readonly PoolSaison2019Context _context;

        public ParticipantsController(PoolSaison2019Context context)
        {
            _context = context;
        }

        // GET: Participants
        public async Task<IActionResult> Index()
        {
			ViewData["Participants"] = await _context.Participant.ToListAsync();
			return View(await _context.Participant.ToListAsync());
        }
	}
}
